package org.elsys.example1.code;

public class HellowWorld {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("we are in bussiness!");

	}

}

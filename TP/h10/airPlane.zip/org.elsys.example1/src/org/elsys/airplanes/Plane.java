package org.elsys.airplanes;

import java.util.ArrayList;
import java.util.List;

public class Plane {

	private List<PlaneSeat> seats;

	public Plane(){
		this.seats = new ArrayList<PlaneSeat>();
		for(int i = 0; i < 27; i++){
			for(int j = 0; j < 6; j++){
				PlaneSeat seat = new PlaneSeat();
				seat.setRow(i);
				seat.setColumn(j);
				seat.setTaken(false);
				if(j != 2 ){
					seat.setNextToTrail(false);
				}else{
					seat.setNextToTrail(true);
				}
				
				seats.add(seat);
			}
		}
	}
	
	public List<PlaneSeat> getSeats(){
		return this.seats;
	}

	public void addPassengers(List<Passanger> passangers) {
		Integer passangersCount = passangers.size();
		
		System.out.println("Group of " + passangersCount.toString() + " arrives.");
		
		int avaiableSeat = findAvaiableSeat(passangers.size());
		if (avaiableSeat >= 0) {
			for (Passanger passanger : passangers) {
				seats.get(avaiableSeat).setPassanger(passanger);
				seats.get(avaiableSeat).setTaken(true);
				String readableSeatAddress = seats.get(avaiableSeat).seatToReadable();
				System.out.println(readableSeatAddress + " is taken!");
				avaiableSeat++;
			}
		}
	}

	public int findAvaiableSeat(int passangerCount) {
		for (int i = 0; i < seats.size(); i++) {
			switch (passangerCount) {
			case 1:
				if (!seats.get(i).isTaken()) {
					return i;
				}
				break;
			case 2:
				if (!seats.get(i).isTaken() && !seats.get(i).isNextToTrail()) {
					int index = i+1;
					if (index > 161) return -1;
					if (!seats.get(index).isTaken())
						return i;
				}
				break;
			case 3:
				if (!seats.get(i).isTaken() && !seats.get(i).isNextToTrail()) {
					int index = i+2;
					if (index > 161) return -1;
					if (!seats.get(i + 1).isTaken()
							&& !seats.get(i + 2).isTaken())
						return i;
				}
				break;
			}
		}
		return -1;
	}
	
	public boolean planeFull(){
		for(PlaneSeat seat : seats){
			if(!seat.isTaken()){
				return false;
			}
		}
		return true;
	}
}

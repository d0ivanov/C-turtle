package org.elsys.airplanes;

import java.util.List;
import java.util.Random;

public class MainClass {

	public static void main(String[] args) {
		Plane plane = new Plane();
		Integer people = 0;
		while(!plane.planeFull()){
			Passanger passanger = new Passanger();
			int rval = new Random().nextInt(3) + 1;
			List<Passanger> randomPeople = passanger.generateRandom(rval);
			if(people + rval <= 162){
				people += rval;
			}
			plane.addPassengers(randomPeople);
		}
		System.out.println(people.toString() + " people boarded the plane!");
	}
}

package org.elsys.airplanes;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Passanger {

	private String name;
	private int gender;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getGender() {
		return gender;
	}

	public void setGender(int gender) {
		this.gender = gender;
	}

	public List<Passanger> generateRandom(int count) {
		List<Passanger> randomPassangers = new ArrayList<Passanger>();
		for (int i = 0; i < count; i++) {
			Passanger passanger = new Passanger();
			passanger.setName(new RandomString(5).nextString());
			passanger.setGender(new Random().nextInt(2) + 1);

			randomPassangers.add(passanger);
		}
		return randomPassangers;
	}
}

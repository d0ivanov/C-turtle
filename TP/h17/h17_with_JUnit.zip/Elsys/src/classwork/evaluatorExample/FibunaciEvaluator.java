package classwork.evaluatorExample;


public class FibunaciEvaluator extends Evaluator {
	
	@Override
	public Double evaluate() {
		double res = 0;
		for(Double d : evaluated) {
			res += d;
		}
		return findClosest(res);
	}

	@Override
	public Double doEvaluate(Double d) {
		return d;
	}
	
	private Double findClosest(Double d) {
		double prev1=0, prev2=1;
		for(; prev1 < d; ) {
			double savePrev1 = prev1;
            prev1 = prev2;
            prev2 = savePrev1 + prev2;
		}
		return prev1;
	}
}

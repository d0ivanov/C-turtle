package classwork.evaluatorExample;


public class PowerOnEvaluator extends Evaluator {

	private double power; 
	
	public PowerOnEvaluator(Double power) {
		this.power = power;
	}

	@Override
	public Double doEvaluate(Double d) {
		return Math.pow(d, power);
	}

}

package classwork.evaluatorExample;

public class EvaluatorFactory implements IEvaluatorFactory {

	@Override
	public IEvaluator createSumEvaluator() {
		return new PowerOnEvaluator(1.0);
	}

	@Override
	public IEvaluator createPowerOnEvaluator() {
		return new PowerOnEvaluator(2.0);
	}
	
	@Override
	public IEvaluator createPowerOnEvaluator(double power) {
		return new PowerOnEvaluator(power);
	}
	
	@Override
	public IEvaluator createFibonaciEvaluator() {
		return new FibunaciEvaluator();
	}

}

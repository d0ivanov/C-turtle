package classwork.evaluatorExample;

public interface IEvaluator {

	public void add(Double d);
	
	public Double evaluate();
}

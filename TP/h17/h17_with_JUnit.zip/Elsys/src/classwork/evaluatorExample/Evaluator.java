package classwork.evaluatorExample;

import java.util.ArrayList;
import java.util.List;

public abstract class Evaluator implements IEvaluator {

	protected List<Double> evaluated = new ArrayList<Double>();
	
	public void add(Double d) {
		evaluated.add(d);
	}
	
	public Double evaluate() {
		Double res = 0.0;
		for (Double d : evaluated) {
			res += doEvaluate(d);
		}
		return res;
	}
	
	public abstract Double doEvaluate(Double d);
}

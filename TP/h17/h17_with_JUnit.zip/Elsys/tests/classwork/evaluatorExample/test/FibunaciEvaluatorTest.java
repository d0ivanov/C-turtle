package classwork.evaluatorExample.test;

import static org.junit.Assert.*;

import org.junit.Test;

import classwork.evaluatorExample.FibunaciEvaluator;

public class FibunaciEvaluatorTest {

	@Test
	public void testEvaluate() {
		FibunaciEvaluator e = new FibunaciEvaluator();
		e.add(2.0);
		e.add(4.0);
		assertEquals(8, e.evaluate(), 0.01);
	}
}

package classwork.evaluatorExample.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import classwork.evaluatorExample.PowerOnEvaluator;

public class PowerOnEvaluatorTest {

	@Test
	public void TestPower() {
		PowerOnEvaluator e = new PowerOnEvaluator(2.0d);
		e.add(2.0);
		e.add(3.0);
		assertEquals(13, e.evaluate(), 0.01);	
	}
	
	@Test
	public void testEvaluate() {
		PowerOnEvaluator e = new PowerOnEvaluator(1.0d);
		e.add(2.0);
		e.add(3.0);
		assertEquals(5, e.evaluate(), 0.01);
	}

}

package org.ballContainer.tests;

import static org.junit.Assert.*;

import org.ballContainer.Ball;
import org.ballContainer.BallContainer;
import org.junit.Before;
import org.junit.Test;

public class ContainerTests {

	private BallContainer container;

	@Before
	public void setUp() {
		container = new BallContainer(10);
	}

	@Test
	public void testAdd() {
		Ball b = new Ball(1, "b1", "r");
		container.add(b);

		assertEquals(1, container.getFilled());
	}

	@Test
	public void testRemove() {
		Ball b = new Ball(1, "b1", "r");
		container.add(b);
		container.remove(b);
		
		assertEquals(10, container.getCapacity());
	}

	@Test
	public void testCapacity() {
		Ball b = new Ball(2, "b2", "g");
		container.add(b);

		assertEquals(8, container.getCapacity());
	}

	@Test
	public void testGetFilled() {
		Ball b = new Ball(3, "b3", "b");
		container.add(b);

		assertEquals(3, container.getFilled());
	}

	@Test
	public void testContains() {
		Ball b = new Ball(4, "b4", "y");
		container.add(b);
		
		assertEquals(true, container.contains(b));
	}
	
	@Test
	public void testFree() {
		Ball b = new Ball(5, "b5", "bl");
		container.add(b);
		container.free();
		
		assertEquals(0, container.getFilled());
	}
	
	@Test
	public void testGetFromSmallest() {
		Ball b1 = new Ball(1, "b6", "r");
		Ball b2 = new Ball(2, "b7", "r");
		Ball b3 = new Ball(3, "b8", "r");
		
		container.add(b1);
		container.add(b2);
		container.add(b3);
		
		assertEquals(1, container.getFromSmallest().getSize());
	}
}

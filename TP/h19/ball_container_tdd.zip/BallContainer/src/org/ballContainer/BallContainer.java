package org.ballContainer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BallContainer {

	private int size;
	private List<Ball> container = new ArrayList<Ball>();

	public BallContainer(int size) {
		this.size = size;
	}

	public void add(Ball b) {
		if (!contains(b) && getCapacity() > b.getSize()) {
			container.add(b);
		}
	}

	public void remove(Ball b) {
		if (contains(b)) {
			container.remove(b);
		}
	}

	public int getCapacity() {
		return size - getFilled();
	}

	public int getFilled() {
		int filled = 0;
		for (Ball b : container) {
			filled += b.getSize();
		}
		return filled;
	}

	public boolean contains(Ball b) {
		return container.contains(b);
	}

	public void free() {
		container.clear();
	}

	public Ball getFromSmallest() {
		Collections.sort(container);
		return container.get(0);
	}
}

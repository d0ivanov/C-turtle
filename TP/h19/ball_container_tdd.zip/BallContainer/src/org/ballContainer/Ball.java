package org.ballContainer;

public class Ball implements Comparable<Ball> {

	private int size;
	public String name;
	public String color;

	public Ball(int size, String name, String color) {
		this.size = size;
		this.name = name;
		this.color = color;
	}
	
	public int getSize() {
		return size;
	}

	@Override
	public int compareTo(Ball other) {
		return this.size - other.size;
	}

}
